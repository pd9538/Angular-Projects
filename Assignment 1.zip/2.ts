function Area(radius:number,pi:number=3.14)
{
    return pi*radius*radius;
}

var iret:number;

iret=Area(5);
console.log("Area of circle is:"+iret);